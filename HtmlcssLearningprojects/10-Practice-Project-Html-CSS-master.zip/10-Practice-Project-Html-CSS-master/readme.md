# HTML CSS 10 PRACTICE PROJECT

### Project that we are going to build in this complete practice course

- Project 1 - Tribute Website
- Project 2 - Job Application
- Project 3 - Parallax Wesbite
- Project 4 - Landing Page
- Project 5 - Restaurant Website
- Project 6 - Music Website
- Project 7 - Youtube Clone
- Project 8 - Javascript Documentation
- Project 9 - Blog Wesbite
- Project 10 - Portfolio Website

#### All Image Assets and Icons will Provided in Video Description

You Can Support me - For Free , Just By Sending me Tip From Brave Browser. ( <b>BAT Coin </b>)

[![image](https://raw.githubusercontent.com/anshuopinion/10-Practice-Project-Html-CSS/master/Readme%20File/howtosupport.png)](https://www.youtube.com/c/dosomecoding)

Visit Channel - [Do some coding](https://www.youtube.com/c/dosomecoding)
›
